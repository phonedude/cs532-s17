<html>
<body>

<?php
print_r ($_POST); 
?>

</body>
</html> 